<?php

/**

 * The base configuration for WordPress

 *

 * The wp-config.php creation script uses this file during the

 * installation. You don't have to use the web site, you can

 * copy this file to "wp-config.php" and fill in the values.

 *

 * This file contains the following configurations:

 *

 * * MySQL settings

 * * Secret keys

 * * Database table prefix

 * * ABSPATH

 *

 * @link https://codex.wordpress.org/Editing_wp-config.php

 *

 * @package WordPress

 */


// ** MySQL settings - You can get this info from your web host ** //

/** The name of the database for WordPress */

define( 'DB_NAME', '' );


/** MySQL database username */

define( 'DB_USER', '' );


/** MySQL database password */

define( 'DB_PASSWORD', '' );


/** MySQL hostname */

define( 'DB_HOST', '' );


/** Database Charset to use in creating database tables. */

define( 'DB_CHARSET', 'utf8mb4' );


/** The Database Collate type. Don't change this if in doubt. */

define( 'DB_COLLATE', '' );


/**#@+

 * Authentication Unique Keys and Salts.

 *

 * Change these to different unique phrases!

 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}

 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.

 *

 * @since 2.6.0

 */

define( 'AUTH_KEY',         'M/3!vsjO-Nk_v|PYg5sr>.4W{[2s@Olm5A,~o[0`jL#lEvOHt! KuCIZjns3,y~L' );

define( 'SECURE_AUTH_KEY',  'n#wl8fr;Rd<3Ue)[P*[~eJ#Y?>x25NJ.Oc%b<k!X)K[5/hy@MSR |js}xZ!6wv`r' );

define( 'LOGGED_IN_KEY',    'kxO1yj427r*KmWCYnx-*C{3^&iWryBo,S ~LDWk(A?8 !{jcG:Te3x^HA84T+yJ-' );

define( 'NONCE_KEY',        '7*(F=(1K_0D<>E:!&}(Ea^X|^e{&~d@#.,5,+H$Efgq^k0Ca?Sm @tJU``Q(OvF/' );

define( 'AUTH_SALT',        '|&tH:];@w wkY&2|[nzPogk|6L|bliSX%u(nKt>]DJzU%m9|)J;+$aeNU+,}+Re ' );

define( 'SECURE_AUTH_SALT', '&~>-|(VtzJ3NH9,Cg09h9ee.~C&BmwCPWzo(98|99HDNki2>=VX%rbH!B0nhXTVN' );

define( 'LOGGED_IN_SALT',   '8)Oz:%_Rvy>#mTe<MQy3Un=E,<-{@(uO4Ux-i[I70>Qn:,Q/Ce<#F8ZX2joB|=+h' );

define( 'NONCE_SALT',       'i,gn@*Xb3f_^={-x:L#KI~BTWMs-]6fp%?Z5Ey`$AI9!2PHmr[@V2<fE@G6u1i+{' );


/**#@-*/


/**

 * WordPress Database Table prefix.

 *

 * You can have multiple installations in one database if you give each

 * a unique prefix. Only numbers, letters, and underscores please!

 */

$table_prefix = 'wp_';


/**

 * For developers: WordPress debugging mode.

 *

 * Change this to true to enable the display of notices during development.

 * It is strongly recommended that plugin and theme developers use WP_DEBUG

 * in their development environments.

 *

 * For information on other constants that can be used for debugging,

 * visit the Codex.

 *

 * @link https://codex.wordpress.org/Debugging_in_WordPress

 */

define( 'WP_DEBUG', false );


/* That's all, stop editing! Happy publishing. */


/** Absolute path to the WordPress directory. */

if ( ! defined( 'ABSPATH' ) ) {

	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

}


/** Sets up WordPress vars and included files. */

require_once( ABSPATH . 'wp-settings.php' );

